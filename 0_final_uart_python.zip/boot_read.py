# boot_read.py
import serial, time
s = serial.Serial('COM10', 9600, timeout=2)
s.reset_input_buffer()
input("이제 보드의 SW0을 0→1로 토글하고 Enter를 누르세요...")
print(repr(s.readline()))  # 기대: b'BOOT\n'
s.close()