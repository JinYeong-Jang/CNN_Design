# mem2bin.py : Xilinx/MIF 스타일 .mem 파일에서 1바이트 HEX들을 뽑아 .bin으로 저장
# - 줄 시작의 '@주소' 라인은 무시
# - //, #, ; 뒤의 코멘트는 무시
# - 1~2자리 HEX 토큰만 바이트로 변환
import sys, re

def parse_mem(path):
    data = []
    with open(path, 'r', encoding='utf-8', errors='ignore') as f:
        for line in f:
            # 코멘트 제거
            line = line.split('//', 1)[0].split('#', 1)[0].split(';', 1)[0]
            s = line.strip()
            if not s:
                continue
            if s.lstrip().startswith('@'):   # 주소 라인 무시
                continue
            # 1~2자리 HEX 토큰만 수집
            for tok in re.findall(r'\b[0-9A-Fa-f]{1,2}\b', s):
                data.append(int(tok, 16))
    return data

def main():
    if len(sys.argv) < 3:
        print("사용법: python mem2bin.py <입력.mem> <출력.bin> [--force-784]")
        sys.exit(1)
    inp = sys.argv[1]
    outp = sys.argv[2]
    data = parse_mem(inp)

    if len(sys.argv) >= 4 and sys.argv[3] == '--force-784':
        if len(data) < 784:
            print(f"에러: {len(data)}바이트만 발견됨 (784 필요).")
            sys.exit(2)
        data = data[:784]

    with open(outp, 'wb') as g:
        g.write(bytes(data))
    print(f"OK: {len(data)} bytes -> {outp}")

if __name__ == "__main__":
    main()