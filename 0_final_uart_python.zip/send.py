import serial, struct

PORT = 'COM10'   # 환경에 맞게
BAUD = 9600  # 1Mbps 추천

def send_image_u8(port, img_u8_flat):  # len=784, [0..255]
    assert len(img_u8_flat) == 784
    # 패킷 생성
    hdr = bytes([0xA5, 0x5A])
    length = struct.pack('>H', 784)   # big-endian 2B
    payload = bytes(img_u8_flat)      # 이미 리스트/np.uint8 1D
    x = 0
    for b in length + payload:
        x ^= b
    tail = bytes([x ^ 0x00, 0x0D])    # XOR, 테일
    pkt = hdr + length + payload + tail
    port.write(pkt)

if __name__ == "__main__":
    import numpy as np
    ser = serial.Serial(PORT, BAUD, timeout=1)
    # MNIST 0~255 이미지 1장을 flat으로 준비했다고 가정
    img = np.fromfile("mnist_1_0_u8.bin", dtype=np.uint8)  # 784 bytes
    send_image_u8(ser, img.tolist())
    # 4-pass가 하드웨어에서 복제되도록 설계했다면 1번만 전송
    # (호스트에서 4번 보내려면 send_image_u8(…)을 4번 호출)