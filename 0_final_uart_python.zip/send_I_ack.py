# send_I_ack.py
import serial
s = serial.Serial('COM10', 9600, timeout=2)
s.reset_input_buffer()
s.write(b'I')                 # 'I' 1바이트 전송
print(repr(s.readline()))     # 기대: b'ACK\n'
s.close()