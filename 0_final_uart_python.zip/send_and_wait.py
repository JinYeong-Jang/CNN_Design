# send_and_wait.py  (COM, baud, 이미지 파일/버퍼만 너 환경에 맞게)
import serial, time, sys

PORT = 'COM10'
BAUD = 9600
TIMEOUT = 3

img_bytes = open('mnist_0_0_u8.bin','rb').read()

with serial.Serial(PORT, BAUD, timeout=1) as s:
    s.reset_input_buffer()
    s.write(b'I' + img_bytes)
    t0 = time.time()
    got_c = False
    print('[host] sent I+784, waiting for lines...')
    while time.time() - t0 < TIMEOUT:
        line = s.readline()
        if not line:
            continue
        print('[rx]', repr(line))
        if line.startswith(b'C,'):
            got_c = True
            break

    if not got_c:
        print('[host] no "C," within timeout')