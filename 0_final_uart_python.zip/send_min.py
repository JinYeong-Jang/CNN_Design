import serial, time, sys, os

PORT = 'COM10'      # 너 컴퓨터에서 FTDI가 잡힌 포트
BAUD = 9600

IMG = 'mnist_0_0_u8.bin'    # 아까 만든 784바이트 파일

def load_784(path):
    if not os.path.exists(path):
        print(f'파일 없음: {path}')
        sys.exit(1)
    data = open(path,'rb').read()
    n = len(data)
    if n != 784:
        print(f'크기 {n} bytes (784 필요)')
        sys.exit(2)
    return data

if __name__ == "__main__":
    payload = load_784(IMG)
    print(f'[{PORT}] open 시도...')
    with serial.Serial(PORT, BAUD, timeout=2) as ser:
        time.sleep(0.1)  # FTDI 안정화
        n = ser.write(b'I' + payload)   # FPGA가 기대하는 프로토콜
        print(f'sent {n} bytes')
        # FPGA가 분류 끝내면 "C,<digit>\n" 보냄
        line = ser.readline()
        print(f'rx raw: {line!r}')
        try:
            print('rx text:', line.decode(errors='ignore').strip())
        except:
            pass
